

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Histori Infaq Gedung</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Histori Pembayaran Infaq Gedung</div>

                    <?php $__currentLoopData = $infaqHistori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border-top">
                            <div class="float-right">
                                <i class="mdi mdi-check text-success"></i> <?php echo e($value->created_at->format('d M, Y')); ?>

                            </div>
                            <div class="mt-4 text-uppercase">
                                <?php echo e($value->siswa->nama . ' - ' . $value->siswa->kelas->nama_kelas); ?>

                            </div>
                            <div>Paket Infaq <b class="text-uppercase"><?php echo e($value->infaqGedung->paket ?? '-'); ?></b></div>
                            <div>=========================</div>
                            <div>Total Infaq Rp. <?php echo e(number_format($value->infaqGedung->nominal ?? 0, 0, ',', '.')); ?></div>
                            <div>Angsuran Ke-<?php echo e($value->angsuran_ke); ?></div>
                            <div>=========================</div>
                            <?php
                                $totalDibayar = $value->siswa->angsuranInfaq->sum('jumlah_bayar');
                                $sisaPembayaran = $value->infaqGedung->nominal - $totalDibayar;
                            ?>
                            <div>Bayar Rp. <?php echo e(number_format($value->jumlah_bayar, 0, ',', '.')); ?></div>
                            <div>Total Dibayar Rp. <?php echo e(number_format($totalDibayar, 0, ',', '.')); ?></div>
                            <div>Sisa Rp. <?php echo e(number_format($sisaPembayaran, 0, ',', '.')); ?></div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination -->
                    <?php if($infaqHistori->lastPage() != 1): ?>
                        <div class="btn-group float-right">
                            <a href="<?php echo e($infaqHistori->previousPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $infaqHistori->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $infaqHistori->currentPage() ? 'active' : ''); ?>"
                                    href="<?php echo e($infaqHistori->url($i)); ?>"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                            <a href="<?php echo e($infaqHistori->nextPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                    <!-- End Pagination -->

                    <?php if(count($infaqHistori) == 0): ?>
                        <div class="text-center">Tidak ada histori pembayaran infaq gedung</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/history-infaq/index.blade.php ENDPATH**/ ?>