

<?php $__env->startSection('breadcrumb'); ?>
   <li class="breadcrumb-item">Dashboard</li>
   <li class="breadcrumb-item">Pembayaran</li>
   <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-body">
            <div class="card-title">Edit Pembayaran</div>
            
            <form method="post" action="<?php echo e(route('entry-pembayaran.update', $edit->id)); ?>">
               <?php echo csrf_field(); ?>
               <?php echo method_field('put'); ?>
               
               <div class="form-group">
                  <label>NISN Siswa</label>
                  <input type="text" class="form-control <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                         name="nisn" value="<?php echo e(old('nisn', $edit->siswa->nisn)); ?>" readonly>
                  <span class="text-danger"><?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>
               
               <div class="form-group">
                  <label>Nama Siswa</label>
                  <input type="text" class="form-control" value="<?php echo e($edit->siswa->nama); ?>" readonly>
               </div>

               <div class="row">
                  <div class="col-md-4">
                     <div class="form-group">
                        <label>SPP</label>
                        <input type="text" class="form-control" 
                               value="Rp <?php echo e(number_format($edit->nominal_spp, 0, ',', '.')); ?>" readonly>
                     </div>
                  </div>
                  <?php if($edit->nominal_konsumsi > 0): ?>
                  <div class="col-md-4">
                     <div class="form-group">
                        <label>Konsumsi</label>
                        <input type="text" class="form-control" 
                               value="Rp <?php echo e(number_format($edit->nominal_konsumsi, 0, ',', '.')); ?>" readonly>
                     </div>
                  </div>
                  <?php endif; ?>
                  <?php if($edit->nominal_fullday > 0): ?>
                  <div class="col-md-4">
                     <div class="form-group">
                        <label>Fullday</label>
                        <input type="text" class="form-control" 
                               value="Rp <?php echo e(number_format($edit->nominal_fullday, 0, ',', '.')); ?>" readonly>
                     </div>
                  </div>
                  <?php endif; ?>
               </div>

               <div class="form-group">
                  <label>Total Tagihan</label>
                  <input type="text" class="form-control" 
                         value="Rp <?php echo e(number_format(
                           $edit->nominal_spp + 
                           ($edit->nominal_konsumsi ?? 0) + 
                           ($edit->nominal_fullday ?? 0), 
                           0, ',', '.')); ?>" readonly>
               </div>

               <div class="form-group">
                  <label>Bulan</label>
                  <select class="form-control <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bulan">
                     <option value="">Pilih Bulan</option>
                     <?php $__currentLoopData = ['januari', 'februari', 'maret', 'april', 'mei', 'juni', 
                              'juli', 'agustus', 'september', 'oktober', 'november', 'desember']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($bulan); ?>" <?php echo e(old('bulan', $edit->bulan) == $bulan ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($bulan)); ?>

                     </option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <span class="text-danger"><?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <div class="form-group">
                  <label>Jumlah Bayar</label>
                  <input type="number" class="form-control <?php $__errorArgs = ['jumlah_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                         name="jumlah_bayar" value="<?php echo e(old('jumlah_bayar', $edit->jumlah_bayar)); ?>" 
                         min="<?php echo e($edit->nominal_spp + ($edit->nominal_konsumsi ?? 0) + ($edit->nominal_fullday ?? 0)); ?>" required>
                  <span class="text-danger"><?php $__errorArgs = ['jumlah_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <div class="form-group">
                  <label>Tanggal Bayar</label>
                  <input type="date" class="form-control <?php $__errorArgs = ['tgl_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                         name="tgl_bayar" value="<?php echo e(old('tgl_bayar', $edit->tgl_bayar->format('Y-m-d'))); ?>" required>
                  <span class="text-danger"><?php $__errorArgs = ['tgl_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <div class="form-group">
                  <label>Status</label>
                  <select class="form-control <?php $__errorArgs = ['is_lunas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="is_lunas">
                     <option value="1" <?php echo e(old('is_lunas', $edit->is_lunas) ? 'selected' : ''); ?>>Lunas</option>
                     <option value="0" <?php echo e(!old('is_lunas', $edit->is_lunas) ? 'selected' : ''); ?>>Belum Lunas</option>
                  </select>
                  <span class="text-danger"><?php $__errorArgs = ['is_lunas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <a href="<?php echo e(route('entry-pembayaran.index')); ?>" class="btn btn-primary btn-rounded">
                  <i class="mdi mdi-chevron-left"></i> Kembali
               </a>
               <button type="submit" class="btn btn-success btn-rounded float-right">
                  <i class="mdi mdi-check"></i> Simpan Perubahan
               </button>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/entri-pembayaran/edit.blade.php ENDPATH**/ ?>