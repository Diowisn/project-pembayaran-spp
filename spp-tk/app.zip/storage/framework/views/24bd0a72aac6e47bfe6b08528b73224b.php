

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Infaq Gedung</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Entri Pembayaran Infaq Gedung</div>

                    <form method="GET" action="<?php echo e(route('infaq.cari-siswa')); ?>">
                        <div class="form-group">
                            <label for="nisn">Cari Berdasarkan NISN</label>
                            <div class="input-group">
                                <input type="text" name="nisn" class="form-control" placeholder="Masukkan NISN"
                                    value="<?php echo e(old('nisn', $siswa->nisn ?? '')); ?>" required>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Cari</button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <?php if(isset($siswa)): ?>
                        <form method="post" action="<?php echo e(route('infaq.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="nisn" value="<?php echo e($siswa->nisn); ?>">
                            <input type="hidden" name="id_siswa" value="<?php echo e($siswa->id); ?>">

                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" class="form-control" value="<?php echo e($siswa->nama ?? ''); ?>" disabled>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Paket Infaq Gedung</label>
                                        <input type="text" class="form-control"
                                            value="<?php echo e($siswa->infaqGedung->paket ?? 'Tidak ada paket'); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Total Infaq Gedung</label>
                                        <input type="text" class="form-control"
                                            value="<?php echo e(isset($siswa->infaqGedung) ? 'Rp ' . number_format($siswa->infaqGedung->nominal, 0, ',', '.') : 'Rp 0'); ?>"
                                            disabled>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Total Sudah Dibayar</label>
                                        <input type="text" class="form-control"
                                            value="Rp <?php echo e(number_format($total_dibayar ?? 0, 0, ',', '.')); ?>" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Sisa Pembayaran</label>
                                        <input type="text" class="form-control"
                                            value="Rp <?php echo e(number_format($sisa_pembayaran ?? 0, 0, ',', '.')); ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Status</label>
                                <input type="text" class="form-control <?php echo e($sisa_pembayaran <= 0 ? 'text-success' : 'text-warning'); ?>"
                                    value="<?php echo e($sisa_pembayaran <= 0 ? 'LUNAS' : 'BELUM LUNAS'); ?>" disabled>
                            </div>

                            <div class="form-group">
                                <label>Jumlah Bayar</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['jumlah_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jumlah_bayar" value="<?php echo e(old('jumlah_bayar')); ?>" required min="1"
                                    max="<?php echo e($sisa_pembayaran ?? 0); ?>">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['jumlah_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <div class="form-group">
                                <label>Tanggal Bayar</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_bayar" value="<?php echo e(old('tgl_bayar', date('Y-m-d'))); ?>" required>
                                <span class="text-danger">
                                    <?php $__errorArgs = ['tgl_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>

                            <button type="submit" class="btn btn-success btn-rounded float-right">
                                <i class="mdi mdi-check"></i> Simpan
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <!-- Form Pencarian -->
            <div class="card mb-3">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('infaq.index')); ?>" class="form-inline">
                        <input type="text" name="search" class="form-control mr-2" placeholder="Cari NISN / Nama Siswa"
                            value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary mr-2">Cari</button>

                        <?php if(request()->has('search')): ?>
                            <a href="<?php echo e(route('infaq.index')); ?>" class="btn btn-secondary">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-title">Data Pembayaran Infaq</div>

                    <div class="table-responsive mb-3">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">NISN SISWA</th>
                                    <th scope="col">NAMA SISWA</th>
                                    <th scope="col">PAKET</th>
                                    <th scope="col">ANGSURAN KE</th>
                                    <th scope="col">
                                        <a href="<?php echo e(route('infaq.index', [
                                            'search' => request('search'),
                                            'sort_by' => 'jumlah_bayar',
                                            'order' => request('sort_by') == 'jumlah_bayar' && request('order') == 'asc' ? 'desc' : 'asc',
                                        ])); ?>"
                                            class="text-dark">
                                            JUMLAH BAYAR
                                            <?php if(request('sort_by') == 'jumlah_bayar'): ?>
                                                <i class="mdi mdi-chevron-<?php echo e(request('order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">
                                        <a href="<?php echo e(route('infaq.index', [
                                            'search' => request('search'),
                                            'sort_by' => 'tgl_bayar',
                                            'order' => request('sort_by') == 'tgl_bayar' && request('order') == 'asc' ? 'desc' : 'asc',
                                        ])); ?>"
                                            class="text-dark">
                                            TANGGAL BAYAR
                                            <?php if(request('sort_by') == 'tgl_bayar'): ?>
                                                <i class="mdi mdi-chevron-<?php echo e(request('order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th scope="col">AKSI</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = ($angsuran->currentPage() - 1) * $angsuran->perPage() + 1;
                                ?>
                                <?php $__currentLoopData = $angsuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->siswa->nisn); ?></td>
                                        <td><?php echo e($value->siswa->nama); ?></td>
                                        <td><?php echo e($value->infaqGedung->paket ?? '-'); ?></td>
                                        <td><?php echo e($value->angsuran_ke); ?></td>
                                        <td>Rp <?php echo e(number_format($value->jumlah_bayar, 0, ',', '.')); ?></td>
                                        <td>
                                            <?php if($value->is_lunas): ?>
                                                <span class="badge bg-success">Lunas</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">Belum Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($value->tgl_bayar->format('d M, Y')); ?></td>
                                        <td>
                                            <div class="hide-menu">
                                                <a href="javascript:void(0)" class="text-dark" id="actiondd"
                                                    role="button" data-toggle="dropdown">
                                                    <i class="mdi mdi-dots-vertical"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="actiondd">
                                                    
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(url('dashboard/infaq/' . $value->id . '/edit')); ?>"><i
                                                            class="ti-pencil"></i> Edit
                                                    </a>

                                                    <?php if(auth()->user()->level == 'admin'): ?>
                                                        <form method="post"
                                                            action="<?php echo e(route('infaq.destroy', $value->id)); ?>"
                                                            id="delete<?php echo e($value->id); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>

                                                            <button type="button" class="dropdown-item"
                                                                onclick="deleteData(<?php echo e($value->id); ?>)">
                                                                <i class="ti-trash"></i> Hapus
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if($angsuran->lastPage() != 1): ?>
                        <div class="btn-group float-right">
                            <a href="<?php echo e($angsuran->appends(request()->query())->previousPageUrl()); ?>"
                                class="btn btn-success">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $angsuran->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $angsuran->currentPage() ? 'active' : ''); ?>"
                                    href="<?php echo e($angsuran->appends(request()->query())->url($i)); ?>">
                                    <?php echo e($i); ?>

                                </a>
                            <?php endfor; ?>
                            <a href="<?php echo e($angsuran->appends(request()->query())->nextPageUrl()); ?>"
                                class="btn btn-success">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                    <!-- End Pagination -->

                    <?php if(count($angsuran) == 0): ?>
                        <div class="text-center">Tidak ada data pembayaran infaq!</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweet'); ?>
    function deleteData(id) {
    Swal.fire({
    title: 'PERINGATAN!',
    text: "Yakin ingin menghapus data pembayaran infaq?",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yakin',
    cancelButtonText: 'Batal',
    }).then((result) => {
    if (result.value) {
    $('#delete' + id).submit();
    }
    })
    }
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/infaq/index.blade.php ENDPATH**/ ?>