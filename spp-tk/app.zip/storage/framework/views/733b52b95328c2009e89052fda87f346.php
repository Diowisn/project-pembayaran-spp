

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Pembayaran</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="card-title">Entri Pembayaran</div>
                
                <?php if(!isset($siswa)): ?>
                <!-- Form Pencarian Siswa -->
                <form method="post" action="<?php echo e(route('pembayaran.cari-siswa')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label>Masukkan NISN Siswa</label>
                                <input type="text" name="nisn" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary mt-4">
                                <i class="mdi mdi-magnify"></i> Cari Siswa
                            </button>
                        </div>
                    </div>
                </form>
                <?php else: ?>
                <!-- Form Pembayaran -->
                <form method="post" action="<?php echo e(route('entry-pembayaran.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id_siswa" value="<?php echo e($siswa->id); ?>">
                    <input type="hidden" name="nisn" value="<?php echo e($nisn); ?>">
                    <input type="hidden" name="jumlah_tagihan" value="<?php echo e($siswa->spp->nominal_spp + ($siswa->spp->nominal_konsumsi ?? 0) + ($siswa->spp->nominal_fullday ?? 0)); ?>">
                    <input type="hidden" name="nominal_spp" value="<?php echo e($siswa->spp->nominal_spp); ?>">
                    <input type="hidden" name="nominal_konsumsi" value="<?php echo e($siswa->spp->nominal_konsumsi ?? 0); ?>">
                    <input type="hidden" name="nominal_fullday" value="<?php echo e($siswa->spp->nominal_fullday ?? 0); ?>">

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>NISN</label>
                                <input type="text" class="form-control" value="<?php echo e($nisn); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama Siswa</label>
                                <input type="text" class="form-control" value="<?php echo e($siswa->nama); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>SPP</label>
                                <input type="text" class="form-control" value="Rp <?php echo e(number_format($siswa->spp->nominal_spp, 0, ',', '.')); ?>" readonly>
                            </div>
                        </div>
                        <?php if($siswa->spp->nominal_konsumsi): ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Konsumsi</label>
                                <input type="text" class="form-control" value="Rp <?php echo e(number_format($siswa->spp->nominal_konsumsi, 0, ',', '.')); ?>" readonly>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($siswa->spp->nominal_fullday): ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Fullday</label>
                                <input type="text" class="form-control" value="Rp <?php echo e(number_format($siswa->spp->nominal_fullday, 0, ',', '.')); ?>" readonly>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Total Tagihan</label>
                                <input type="text" class="form-control" 
                                    value="Rp <?php echo e(number_format($siswa->spp->nominal_spp) + ($siswa->spp->nominal_konsumsi ?? 0) + ($siswa->spp->nominal_fullday ?? 0), 0, ',', '.'); ?>" 
                                    readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Tahun</label>
                                <input type="number" name="tahun" class="form-control" value="<?php echo e(date('Y')); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nominal Pembayaran</label>
                                <input type="number" name="nominal_pembayaran" class="form-control" 
                                    min="<?php echo e($siswa->spp->nominal_spp + ($siswa->spp->nominal_konsumsi ?? 0) + ($siswa->spp->nominal_fullday ?? 0)); ?>" 
                                    required>
                            </div>
                        </div>
                    </div>

                    <div class="text-right">
                        <a href="<?php echo e(route('entry-pembayaran.create')); ?>" class="btn btn-secondary">
                            <i class="mdi mdi-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-success">
                            <i class="mdi mdi-check"></i> Simpan Pembayaran
                        </button>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-body">
                    <div class="card-title">Data Pembayaran</div>

                    <div class="table-responsive mb-3">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">PETUGAS</th>
                                    <th scope="col">NISN SISWA</th>
                                    <th scope="col">NAMA SISWA</th>
                                    <th scope="col">SPP</th>
                                    <th scope="col">JUMLAH BAYAR</th>
                                    <th scope="col">TANGGAL BAYAR</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->petugas->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($value->siswa->nisn); ?></td>
                                        <td><?php echo e($value->siswa->nama); ?></td>
                                        <td><?php echo e($value->siswa->spp->nominal); ?></td>
                                        <td><?php echo e($value->jumlah_bayar); ?></td>
                                        <td><?php echo e($value->created_at->format('d M, Y')); ?></td>
                                        <td>
                                            <div class="hide-menu">
                                                <a href="javascript:void(0)" class="text-dark" id="actiondd" role="button"
                                                    data-toggle="dropdown">
                                                    <i class="mdi mdi-dots-vertical"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="actiondd">
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(url('dashboard/pembayaran/' . $value->id . '/edit')); ?>"><i
                                                            class="ti-pencil"></i> Edit </a>
                                                    <form method="post"
                                                        action="<?php echo e(url('dashboard/pembayaran', $value->id)); ?>"
                                                        id="delete<?php echo e($value->id); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>

                                                        <button type="button" class="dropdown-item"
                                                            onclick="deleteData(<?php echo e($value->id); ?>)">
                                                            <i class="ti-trash"></i> Hapus
                                                        </button>

                                                    </form>

                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <?php if($pembayaran->lastPage() != 1): ?>
                        <div class="btn-group float-right">
                            <a href="<?php echo e($pembayaran->previousPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $pembayaran->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $pembayaran->currentPage() ? 'active' : ''); ?>"
                                    href="<?php echo e($pembayaran->url($i)); ?>"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                            <a href="<?php echo e($pembayaran->nextPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                    <!-- End Pagination -->

                    <?php if(count($pembayaran) == 0): ?>
                        <div class="text-center">Tidak ada data!</div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweet'); ?>
        function deleteData(id) {
            Swal.fire({
                title: 'PERINGATAN!',
                text: "Yakin ingin menghapus data SPP?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yakin',
                cancelButtonText: 'Batal',
            }).then((result) => {
                if (result.value) {
                    $('#delete' + id).submit();
                }
            })
        }
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function() {
    $('#nisn').on('blur', function() {
        let nisn = $(this).val().trim();
        if (!nisn) return;

        $.ajax({
            url: '/dashboard/pembayaran/' + nisn,
            type: 'GET',
            dataType: 'json',
            success: function(res) {
                if (!res.data) {
                    alert('Siswa tidak ditemukan');
                    return;
                }

                const d = res.data;
                $('#nama').val(d.nama);
                $('input[name="id_siswa"]').val(d.id_siswa);

                $('#nominal_spp').val(formatRupiah(d.nominal_spp));
                $('#nominal_spp_hidden').val(d.nominal_spp);

                toggleField('#konsumsi-field', '#nominal_konsumsi', d.nominal_konsumsi);
                toggleField('#fullday-field', '#nominal_fullday', d.nominal_fullday);

                let total = d.nominal_spp + d.nominal_konsumsi + d.nominal_fullday;
                $('#jumlah_bayar').val(formatRupiah(total));
            },
            error: function(xhr) {
                console.error('Error:', xhr.responseText);
                alert('Terjadi kesalahan saat mengambil data siswa');
            }
        });
    });

    function toggleField(selector, inputSelector, value) {
        if (value > 0) {
            $(selector).show();
            $(inputSelector).val(formatRupiah(value));
            $(inputSelector + '_hidden').val(value);
        } else {
            $(selector).hide();
            $(inputSelector).val('');
            $(inputSelector + '_hidden').val('');
        }
    }

    function formatRupiah(angka) {
        return 'Rp ' + angka.toLocaleString('id-ID');
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/entri-pembayaran/create.blade.php ENDPATH**/ ?>