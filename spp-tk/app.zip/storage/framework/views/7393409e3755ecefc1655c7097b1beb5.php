

<?php $__env->startSection('breadcrumb'); ?>
     <li class="breadcrumb-item">Dashboard</li>
	<li class="breadcrumb-item">Petugas</li>
     <li class="breadcrumb-item active">Tambah</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
         <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                       <div class="card-title"><?php echo e(__('Tambah Petugas')); ?></div>
                     
                        <form method="post" action="<?php echo e(url('dashboard/data-petugas', $edit->id)); ?>" id="edit_data">
                        
                           <?php echo csrf_field(); ?>
                           <?php echo method_field('put'); ?>
                           
                           <div class="input-group mb-3">									
                        <div class="input-group-prepend">										
                           <label class="input-group-text">										 	
                              Level	
                           </label>
                        </div>
                        <select name="level" class="custom-select <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">							
                              <option value="">Silahkan Pilih</option>											
                              <option value="admin" <?php echo e($edit->level == 'admin' ? 'selected' : ''); ?>>admin</option>
                              <option value="petugas" <?php echo e($edit->level == 'petugas' ? 'selected' : ''); ?>>petugas</option>
                       </select>
                     </div>
                     <span class="text-danger"><?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               
   
                           <div class="form-group">
                              <label>Nama</label>
                              <input type="text" id="nama" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" value="<?php echo e($edit->name); ?>">
                              <span class="text-danger"><?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                           </div>
                           
                           <div class="form-group">
                              <label>Email</label>
                              <input type="email" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($edit->email); ?>">
                              <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                           </div>
                           
                           <div class="form-group">
                              <label>Password Baru (Opsional)</label>
                              <input type="password" id="new_pass" class="form-control <?php $__errorArgs = ['password_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_baru">
                              <span class="text-danger"><?php $__errorArgs = ['password_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                           </div>
                           
                           <div class="form-group">
                              <label>Konfirmasi Password Baru</label>
                              <input type="password" id="confirm_new_pass" class="form-control">
                              <span class="text-danger"><?php $__errorArgs = ['password_baru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                           </div>
                           
                           <input type="hidden" id="old_pass" name="old_pass" value="">
                           
                           <a href="<?php echo e(url('dashboard/data-petugas')); ?>" class="btn btn-primary btn-rounded">
                              <i class="mdi mdi-chevron-left"></i> Kembali
                           </a>
                           
                           <button type="button" class="btn btn-success btn-rounded float-right" onclick="buttonEdit()">
                                 <i class="mdi mdi-check"></i> Simpan
                           </button>
                        
                        </form>
                  </div>
              </div>     
            </div>
         
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweet'); ?>

    function buttonEdit()
    {    
      var new_pass = $('#new_pass').val();
      var confirm_new_pass = $('#confirm_new_pass').val();
   
      if(new_pass == '' ){
            var text = "Masukan Password anda?";
         }else{
            var text = "Masukan Password lama anda?";   
         }
         
         if(new_pass == confirm_new_pass){
               swal.fire({
               icon: 'question',
               title: text,
               input: 'password',
               inputAttributes: {
                  autocapitalize: 'off',
               },
               confirmButtonText: 'Lanjut',
               showLoaderOnConfirm: true,
               showCancelButton: true,
               cancelButtonText: 'Batal',
               cancelButtonColor: '#d33'
            })
            .then((result) => {
               if(result.value){
                      $('#old_pass').val(result.value);
                      $('#edit_data').submit();
                  }else{
                     const Toast = Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 3000,
                        timerProgressBar: true,
                        onOpen: (toast) => {
                           toast.addEventListener('mouseenter', Swal.stopTimer)
                           toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                     });
                    Toast.fire({
                       icon: 'error',
                       title: 'Terjadi Kesalahan!'
                     });
                  }
               });
            }else{
               Toast.fire({
                   icon: 'error',
                   title: 'Konfirmasi Password tidak Cocok!'
                })
            }
         
    }
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/data-petugas/edit.blade.php ENDPATH**/ ?>