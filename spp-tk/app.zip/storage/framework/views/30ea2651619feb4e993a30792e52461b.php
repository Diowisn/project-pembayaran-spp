

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Histori Infaq Gedung</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Histori Pembayaran Infaq Gedung</div>

                    <?php $__currentLoopData = $infaqHistori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-row comment-row">
                            <i class="mdi mdi-home display-3"></i> <!-- Ganti icon untuk infaq -->
                            <div class="comment-text active w-100">
                                <hr>
                                <span class="badge badge-primary badge-rounded float-right">
                                    <?php echo e($history->created_at->diffforHumans()); ?>

                                </span>
                                <h6 class="font-medium"><?php echo e($history->siswa->nama); ?></h6>
                                <span class="m-b-15 d-block">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">Kelas <?php echo e($history->siswa->kelas->nama_kelas); ?></li>
                                        <li class="list-group-item">Paket Infaq
                                            <b class="text-uppercase"><?php echo e($history->infaqGedung->paket ?? '-'); ?></b>
                                        </li>
                                        <li class="list-group-item">Total Infaq Rp.
                                            <?php echo e(number_format($history->infaqGedung->nominal ?? 0, 0, ',', '.')); ?>

                                        </li>
                                        <li class="list-group-item">Angsuran Ke-<?php echo e($history->angsuran_ke); ?></li>
                                        <li class="list-group-item">Jumlah Bayar Rp.
                                            <?php echo e(number_format($history->jumlah_bayar, 0, ',', '.')); ?>

                                        </li>
                                        <?php
                                            $totalDibayar = $history->siswa->angsuranInfaq->sum('jumlah_bayar');
                                            $sisaPembayaran = $history->infaqGedung->nominal - $totalDibayar;
                                        ?>
                                        <li class="list-group-item">Total Dibayar Rp.
                                            <?php echo e(number_format($totalDibayar, 0, ',', '.')); ?>

                                        </li>
                                        <li class="list-group-item">Sisa Pembayaran Rp.
                                            <?php echo e(number_format($sisaPembayaran, 0, ',', '.')); ?>

                                        </li>
                                    </ul>
                                </span>
                                <div class="comment-footer">
                                    <span class="text-muted float-right">
                                        <?php echo e($history->created_at->format('M d, Y')); ?>

                                    </span>
                                    <span class="action-icons active" style="background-color: #4CAF50;">
                                        <a href="<?php echo e(route('siswa.infaq.cetak', $history->id)); ?>" class="mr-2"
                                            title="Cetak Bukti" style="color: white">
                                            <i class="mdi mdi-printer"></i> Cetak Bukti Pembayaran
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination -->
                    <?php if($infaqHistori->lastPage() != 1): ?>
                        <div class="btn-group float-right mt-4">
                            <a href="<?php echo e($infaqHistori->previousPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $infaqHistori->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $infaqHistori->currentPage() ? 'active' : ''); ?>"
                                    href="<?php echo e($infaqHistori->url($i)); ?>"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                            <a href="<?php echo e($infaqHistori->nextPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if(count($infaqHistori) == 0): ?>
                        <div class="text-center">Belum ada histori pembayaran infaq gedung</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/siswa/infaq.blade.php ENDPATH**/ ?>