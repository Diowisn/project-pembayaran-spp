

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Histori</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

            <div class="card">
                <div class="card-body">
                    <div class="card-title">Histori Pembayaran</div>

                    <!--  Row -->
                    <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex flex-row comment-row">
                            <i class="mdi mdi-account display-3"></i>
                            <div class="comment-text active w-100">
                                <hr>
                                <span
                                    class="badge badge-success badge-rounded float-right"><?php echo e($history->created_at->diffforHumans()); ?></span>
                                <h6 class="font-medium"><?php echo e($history->siswa->nama); ?></h6>
                                <span class="m-b-15 d-block">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">Kelas <?php echo e($history->siswa->kelas->nama_kelas); ?> ~ SPP
                                            Bulan <b class="text-capitalize text-bold"><?php echo e($history->bulan); ?></b></li>
                                        <li class="list-group-item">Nominal SPP Rp.
                                            <?php echo e($history->siswa->spp->nominal_spp ?? '-'); ?></li>
                                        <li class="list-group-item">Nominal Konsumsi
                                            Rp.<?php echo e($history->siswa->spp->nominal_konsumsi ?? '-'); ?></li>
                                        <li class="list-group-item">Nominal Fullday Rp.
                                            <?php echo e($history->siswa->spp->nominal_fullday ?? '-'); ?></li>
                                        <li class="list-group-item">Jumlah Bayar Rp. <?php echo e($history->jumlah_bayar); ?></li>
                                        <li class="list-group-item">Kembalian Rp. <?php echo e($history->kembalian); ?></li>
                                    </ul>
                                </span>
                                <div class="comment-footer">
                                    <span class="text-muted float-right"><?php echo e($history->created_at->format('M d, Y')); ?></span>
                                    <span class="action-icons active" style="background-color: #FB9E3A;">
                                        <a href="<?php echo e(route('siswa.pembayaran.cetak', $history->id)); ?>" class="mr-2"
                                            title="Cetak Bukti" style="color: white;">
                                            <i class="mdi mdi-printer"></i> Cetak Bukti Pembayaran 
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination -->
                    <?php if($pembayaran->lastPage() != 1): ?>
                        <div class="btn-group float-right mt-4">
                            <a href="<?php echo e($pembayaran->previousPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $pembayaran->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $pembayaran->currentPage() ? 'active' : ''); ?>"
                                    href="<?php echo e($pembayaran->url($i)); ?>"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                            <a href="<?php echo e($pembayaran->nextPageUrl()); ?>" class="btn btn-success">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                    <!-- End Pagination -->

                    <?php if(count($pembayaran) == 0): ?>
                        <div class="text-center">Tidak ada histori!</div>
                    <?php endif; ?>
                </div>

            </div>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/siswa/index.blade.php ENDPATH**/ ?>