

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Pembayaran</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Entri Pembayaran</div>

                    <form method="GET" action="<?php echo e(route('pembayaran.cari-siswa')); ?>">
                        <div class="form-group">
                            <label for="nisn">Cari Berdasarkan NISN</label>
                            <div class="input-group">
                                <input type="text" name="nisn" class="form-control" placeholder="Masukkan NISN"
                                    value="<?php echo e(old('nisn', $siswa_data->nisn ?? '')); ?>" required>
                                <div class="input-group-append">
                                    <button class="btn btn-primary" type="submit">Cari</button>
                                </div>
                            </div>
                        </div>
                    </form>

                    <?php if(isset($siswa)): ?>
                        <form method="post" action="<?php echo e(route('entry-pembayaran.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="nisn" value="<?php echo e($siswa->nisn); ?>">
                            <input type="hidden" name="id_siswa" value="<?php echo e($siswa->id); ?>">

                            <div class="form-group">
                                <label>Nama</label>
                                <input type="text" class="form-control" value="<?php echo e($siswa->nama ?? ''); ?>" disabled>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Nominal SPP</label>
                                        <input type="text" class="form-control"
                                            value="<?php echo e(isset($siswa) ? 'Rp ' . number_format($siswa->spp->nominal_spp, 0, ',', '.') : ''); ?>"
                                            disabled>
                                        <input type="hidden" name="nominal_spp"
                                            value="<?php echo e($siswa->spp->nominal_spp ?? 0); ?>">
                                    </div>
                                </div>

                                <?php if(isset($siswa) && $siswa->spp->nominal_konsumsi > 0): ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Nominal Konsumsi</label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e('Rp ' . number_format($siswa->spp->nominal_konsumsi, 0, ',', '.')); ?>"
                                                disabled>
                                            <input type="hidden" name="nominal_konsumsi"
                                                value="<?php echo e($siswa->spp->nominal_konsumsi); ?>">
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if(isset($siswa) && $siswa->spp->nominal_fullday > 0): ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Nominal Fullday</label>
                                            <input type="text" class="form-control"
                                                value="<?php echo e('Rp ' . number_format($siswa->spp->nominal_fullday, 0, ',', '.')); ?>"
                                                disabled>
                                            <input type="hidden" name="nominal_fullday"
                                                value="<?php echo e($siswa->spp->nominal_fullday); ?>">
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if($siswa): ?>
                                <?php
                                    $total_bayar =
                                        $siswa->spp->nominal_spp +
                                        $siswa->spp->nominal_konsumsi +
                                        $siswa->spp->nominal_fullday;
                                ?>

                                <div class="form-group">
                                    <label>Total Tagihan</label>
                                    <input type="text" class="form-control"
                                        value="<?php echo e('Rp ' . number_format($total_bayar, 0, ',', '.')); ?>" readonly>
                                    <input type="hidden" name="jumlah_tagihan" value="<?php echo e($total_bayar); ?>">
                                </div>

                                <div class="form-group">
                                    <label>Bulan</label>
                                    <select class="form-control <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bulan"
                                        required>
                                        <option value="">Pilih Bulan</option>
                                        <?php $__currentLoopData = [
                                            'januari' => 'Januari',
                                            'februari' => 'Februari',
                                            'maret' => 'Maret',
                                            'april' => 'April',
                                            'mei' => 'Mei',
                                            'juni' => 'Juni',
                                            'juli' => 'Juli',
                                            'agustus' => 'Agustus',
                                            'september' => 'September',
                                            'oktober' => 'Oktober',
                                            'november' => 'November',
                                            'desember' => 'Desember'
                                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bulan); ?>"
                                                <?php echo e(old('bulan') == $bulan ? 'selected' : ''); ?>>
                                                <?php echo e(ucfirst($bulan)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="form-group">
                                    <label>Jumlah Uang Dibayarkan</label>
                                    <input type="number"
                                        class="form-control <?php $__errorArgs = ['nominal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="nominal_pembayaran" value="<?php echo e(old('nominal_pembayaran')); ?>" required
                                        min="<?php echo e($total_bayar); ?>">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['nominal_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>
                            <?php endif; ?>

                            <button type="submit" class="btn btn-success btn-rounded float-right">
                                <i class="mdi mdi-check"></i> Simpan
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <!-- Form Pencarian -->
            <div class="card mb-3">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('entry-pembayaran.index')); ?>" class="form-inline">
                        <input type="text" name="search" class="form-control mr-2" placeholder="Cari NISN / Nama Siswa"
                            value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary mr-2">Cari</button>

                        <?php if(request()->has('search')): ?>
                            <a href="<?php echo e(route('entry-pembayaran.index')); ?>" class="btn btn-secondary">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="card-title">Data Pembayaran</div>

                    <div class="table-responsive mb-3">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">PETUGAS</th>
                                    <th scope="col">NISN SISWA</th>
                                    <th scope="col">NAMA SISWA</th>
                                    <th scope="col">
                                        <a href="<?php echo e(route('entry-pembayaran.index', [
                                            'search' => request('search'),
                                            'sort_by' => 'jumlah_bayar',
                                            'order' => request('sort_by') == 'jumlah_bayar' && request('order') == 'asc' ? 'desc' : 'asc',
                                        ])); ?>"
                                            class="text-dark">
                                            TOTAL BAYAR
                                            <?php if(request('sort_by') == 'jumlah_bayar'): ?>
                                                <i
                                                    class="mdi mdi-chevron-<?php echo e(request('order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th scope="col">JUMLAH BAYAR</th>
                                    <th scope="col">SISA</th>
                                    <th scope="col">BULAN</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">
                                        <a href="<?php echo e(route('entry-pembayaran.index', [
                                            'search' => request('search'),
                                            'sort_by' => 'created_at',
                                            'order' => request('sort_by') == 'created_at' && request('order') == 'asc' ? 'desc' : 'asc',
                                        ])); ?>"
                                            class="text-dark">
                                            TANGGAL BAYAR
                                            <?php if(request('sort_by') == 'created_at'): ?>
                                                <i
                                                    class="mdi mdi-chevron-<?php echo e(request('order') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $i = ($pembayaran->currentPage() - 1) * $pembayaran->perPage() + 1;
                                ?>
                                <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <td><?php echo e($value->petugas->name ?? 'N/A'); ?></td>
                                        <td><?php echo e($value->siswa->nisn); ?></td>
                                        <td><?php echo e($value->siswa->nama); ?></td>
                                        <td>Rp
                                            <?php echo e(number_format(
                                                $value->nominal_spp + ($value->nominal_konsumsi ?? 0) + ($value->nominal_fullday ?? 0),
                                                0,
                                                ',',
                                                '.',
                                            )); ?>

                                        </td>
                                        <td>Rp <?php echo e(number_format($value->jumlah_bayar, 0, ',', '.')); ?></td>
                                        <td>Rp <?php echo e(number_format($value->kembalian, 0, ',', '.')); ?></td>
                                        <td> <?php echo e(ucfirst($value->bulan)); ?></td>
                                        <td>
                                            <?php if($value->is_lunas): ?>
                                                <span class="badge badge-success">Lunas</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">Belum Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($value->created_at->format('d M, Y')); ?></td>
                                        <td>
                                            <div class="hide-menu">
                                                <a href="javascript:void(0)" class="text-dark" id="actiondd"
                                                    role="button" data-toggle="dropdown">
                                                    <i class="mdi mdi-dots-vertical"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="actiondd">

                                                    <a class="dropdown-item"
                                                        href="<?php echo e(url('dashboard/pembayaran/' . $value->id . '/edit')); ?>">
                                                        <i class="ti-pencil"></i> Edit
                                                    </a>

                                                    <?php if(auth()->user()->level == 'admin'): ?>
                                                        <form method="post"
                                                            action="<?php echo e(url('dashboard/pembayaran', $value->id)); ?>"
                                                            id="delete<?php echo e($value->id); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>

                                                            <button type="button" class="dropdown-item"
                                                                onclick="deleteData(<?php echo e($value->id); ?>)">
                                                                <i class="ti-trash"></i> Hapus
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                        $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if($pembayaran->lastPage() != 1): ?>
                        <div class="btn-group float-right">
                            <a href="<?php echo e($pembayaran->appends(request()->query())->previousPageUrl()); ?>"
                                class="btn btn-success">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $pembayaran->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $pembayaran->currentPage() ? 'active' : ''); ?>"
                                    href="<?php echo e($pembayaran->appends(request()->query())->url($i)); ?>">
                                    <?php echo e($i); ?>

                                </a>
                            <?php endfor; ?>
                            <a href="<?php echo e($pembayaran->appends(request()->query())->nextPageUrl()); ?>"
                                class="btn btn-success">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                    <!-- End Pagination -->

                    <?php if(count($pembayaran) == 0): ?>
                        <div class="text-center">Tidak ada data pembayaran!</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweet'); ?>
    function deleteData(id) {
    Swal.fire({
    title: 'PERINGATAN!',
    text: "Yakin ingin menghapus data SPP?",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yakin',
    cancelButtonText: 'Batal',
    }).then((result) => {
    if (result.value) {
    $('#delete' + id).submit();
    }
    })
    }
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function searchStudent() {
            const nisn = document.getElementById('nisn_input').value;
            const form = document.getElementById('searchForm');
            form.action = "<?php echo e(route('pembayaran.cari-siswa', ['nisn' => ''])); ?>/" + nisn;
            form.submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/entri-pembayaran/index.blade.php ENDPATH**/ ?>