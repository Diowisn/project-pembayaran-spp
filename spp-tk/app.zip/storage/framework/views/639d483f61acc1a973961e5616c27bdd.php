

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">SPP</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title"><?php echo e(__('Tambah Tarif Pembayaran')); ?></div>
                    
<form method="post" action="<?php echo e(url('/dashboard/data-spp')); ?>">
    <?php echo csrf_field(); ?>
    
    <div class="form-group">
        <label>Tahun</label>
        <input type="number" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="tahun" value="<?php echo e(old('tahun', date('Y'))); ?>" min="2020" max="2030" required>
        <span class="text-danger"><?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
    </div>
    
<div class="form-group">
    <label>Kelas</label>
    <select class="form-control <?php $__errorArgs = ['id_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_kelas" required>
        <option value="">-- Pilih Kelas --</option>
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($k->id); ?>" <?php echo e(old('id_kelas') == $k->id ? 'selected' : ''); ?>>
                <?php echo e($k->nama_kelas); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <span class="text-danger"><?php $__errorArgs = ['id_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
</div>
    
    <div class="form-group">
        <label>Nominal SPP (Rp)</label>
        <input type="text" class="form-control <?php $__errorArgs = ['nominal_spp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="nominal_spp" value="<?php echo e(old('nominal_spp')); ?>" id="nominal-spp" required>
        <span class="text-danger"><?php $__errorArgs = ['nominal_spp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
    </div>
    
    <div class="form-group">
        <label>Nominal Konsumsi (Rp)</label>
        <input type="text" class="form-control <?php $__errorArgs = ['nominal_konsumsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="nominal_konsumsi" value="<?php echo e(old('nominal_konsumsi')); ?>" id="nominal-konsumsi">
        <span class="text-danger"><?php $__errorArgs = ['nominal_konsumsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
    </div>
    
    <div class="form-group">
        <label>Nominal Fullday (Rp)</label>
        <input type="text" class="form-control <?php $__errorArgs = ['nominal_fullday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               name="nominal_fullday" value="<?php echo e(old('nominal_fullday')); ?>" id="nominal-fullday">
        <span class="text-danger"><?php $__errorArgs = ['nominal_fullday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
    </div>
    
    
    
    <button type="submit" class="btn btn-success btn-rounded float-right">
        <i class="mdi mdi-check"></i> Simpan
    </button>
</form>

<?php $__env->startSection('scripts'); ?>
<script>
    // Format input nominal
    function formatRupiahInput(inputId) {
        $(`#${inputId}`).on('keyup', function() {
            let value = $(this).val().replace(/\D/g, '');
            $(this).val(formatRupiah(value));
        });
    }

    function formatRupiah(angka) {
        if (!angka) return '';
        return new Intl.NumberFormat('id-ID').format(angka);
    }

    // Format semua input nominal
    formatRupiahInput('nominal-spp');
    formatRupiahInput('nominal-konsumsi');
    formatRupiahInput('nominal-fullday');

    // Set nilai default untuk tahun
    document.querySelector('input[name="tahun"]').value = new Date().getFullYear();
</script>
<?php $__env->stopSection(); ?>
                </div>
            </div>     
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Data Tarif Pembayaran</div>
                    
                    <div class="table-responsive mb-3">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Tahun</th>
                                    <th>Jenis Pembayaran</th>
                                    <th>Kelas</th>
                                    <th>Tagihan</th>
                                    <th>Nominal</th>
                                    <th>Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
<?php $__currentLoopData = $spp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($value->tahun); ?></td>
        <td>
            <!-- Jenis Pembayaran -->
            SPP
            <?php if($value->nominal_konsumsi): ?>
                <br><small class="text-muted">+ Konsumsi</small>
            <?php endif; ?>
            <?php if($value->nominal_fullday): ?>
                <br><small class="text-muted">+ Fullday</small>
            <?php endif; ?>
        </td>
        <td><?php echo e($value->kelas->nama_kelas); ?></td>
        <td>
            <?php if($value->kelas->has_konsumsi): ?>
                <span class="badge badge-info">Konsumsi</span>
            <?php endif; ?>
            <?php if($value->kelas->has_fullday): ?>
                <span class="badge badge-primary">Fullday</span>
            <?php endif; ?>
        </td>
        <td>
            <strong>SPP:</strong> Rp <?php echo e(number_format($value->nominal_spp, 0, ',', '.')); ?><br>
            <?php if($value->nominal_konsumsi): ?>
                <strong>Konsumsi:</strong> Rp <?php echo e(number_format($value->nominal_konsumsi, 0, ',', '.')); ?><br>
            <?php endif; ?>
            <?php if($value->nominal_fullday): ?>
                <strong>Fullday:</strong> Rp <?php echo e(number_format($value->nominal_fullday, 0, ',', '.')); ?>

            <?php endif; ?>
        </td>
        <td><?php echo e($value->created_at->format('d M Y')); ?></td>
        <td>
            <div class="hide-menu">
                <a href="javascript:void(0)" class="text-dark" id="actiondd" role="button" data-toggle="dropdown">
                    <i class="mdi mdi-dots-vertical"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="actiondd">
                    <a class="dropdown-item" href="<?php echo e(url('dashboard/data-spp/'.$value->id.'/edit')); ?>">
                        <i class="ti-pencil"></i> Edit
                    </a>
                    <form method="post" action="<?php echo e(url('dashboard/data-spp', $value->id)); ?>" id="delete<?php echo e($value->id); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="button" class="dropdown-item" onclick="deleteData(<?php echo e($value->id); ?>)">
                            <i class="ti-trash"></i> Hapus
                        </button>
                    </form>
                </div>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if($spp->lastPage() != 1): ?>
                        <div class="btn-group float-right">
                            <a href="<?php echo e($spp->previousPageUrl()); ?>" class="btn btn-success <?php echo e($spp->currentPage() == 1 ? 'disabled' : ''); ?>">
                                <i class="mdi mdi-chevron-left"></i>
                            </a>
                            <?php for($i = 1; $i <= $spp->lastPage(); $i++): ?>
                                <a class="btn btn-success <?php echo e($i == $spp->currentPage() ? 'active' : ''); ?>" href="<?php echo e($spp->url($i)); ?>"><?php echo e($i); ?></a>
                            <?php endfor; ?>
                            <a href="<?php echo e($spp->nextPageUrl()); ?>" class="btn btn-success <?php echo e($spp->currentPage() == $spp->lastPage() ? 'disabled' : ''); ?>">
                                <i class="mdi mdi-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(count($spp) == 0): ?>
                        <div class="text-center">Tidak ada data!</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Tampilkan field paket hanya untuk infaq gedung
    $('select[name="jenis_pembayaran"]').change(function() {
        if ($(this).val() == 'infaq_gedung') {
            $('#paket-container').show();
        } else {
            $('#paket-container').hide();
        }
    });

    // Format input nominal
    $('#nominal-input').on('keyup', function() {
        let value = $(this).val().replace(/\D/g, '');
        $(this).val(formatRupiah(value));
    });

    function formatRupiah(angka) {
        if (!angka) return '';
        return new Intl.NumberFormat('id-ID').format(angka);
    }

    // Jika ada error, pastikan field paket ditampilkan
    <?php if(old('jenis_pembayaran') == 'infaq_gedung'): ?>
        $('#paket-container').show();
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweet'); ?>
function deleteData(id){
    Swal.fire({
        title: 'PERINGATAN!',
        text: "Yakin ingin menghapus data tarif pembayaran?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yakin',
        cancelButtonText: 'Batal',
    }).then((result) => {
        if (result.value) {
            $('#delete'+id).submit();
        }
    })
}
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/data-spp/index.blade.php ENDPATH**/ ?>