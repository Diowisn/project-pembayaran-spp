

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item active">Tabungan</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <!-- Form Pencarian -->
            <div class="card mb-3">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('tabungan.index')); ?>" class="form-inline">
                        <input type="text" name="search" class="form-control mr-2" placeholder="Cari NISN/Nama Siswa"
                            value="<?php echo e(request('search')); ?>">
                        <button type="submit" class="btn btn-primary mr-2">Cari</button>
                        <?php if(request()->has('search')): ?>
                            <a href="<?php echo e(route('tabungan.index')); ?>" class="btn btn-secondary">Reset</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="card-title mb-0">Data Tabungan Siswa</div>
                        <a href="<?php echo e(route('tabungan.create')); ?>" class="btn btn-primary">
                            <i class="mdi mdi-plus"></i> Tambah Setoran Manual
                        </a>
                    </div>

                    <div class="table-responsive mb-3">
                        <table class="table table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th>#</th>
                                    <th>NISN</th>
                                    <th>NAMA SISWA</th>
                                    <th>DEBIT</th>
                                    <th>KREDIT</th>
                                    <th>SALDO</th>
                                    <th>KETERANGAN</th>
                                    <th>TANGGAL</th>
                                    <th>AKSI</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->siswa->nisn); ?></td>
                                        <td><?php echo e($item->siswa->nama); ?></td>
                                        <td class="text-success">Rp <?php echo e(number_format($item->debit, 0, ',', '.')); ?></td>
                                        <td class="text-danger">Rp <?php echo e(number_format($item->kredit, 0, ',', '.')); ?></td>
                                        <td>Rp <?php echo e(number_format($item->saldo, 0, ',', '.')); ?></td>
                                        <td><?php echo e($item->keterangan); ?></td>
                                        <td><?php echo e($item->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('tabungan.show', $item->id_siswa)); ?>"
                                                class="btn btn-sm btn-info">
                                                <i class="mdi mdi-eye"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($tabungan->appends(request()->query())->links()); ?>


                    <?php if(count($tabungan) == 0): ?>
                        <div class="alert alert-warning text-center">
                            Tidak ada data tabungan ditemukan
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/tabungan/index.blade.php ENDPATH**/ ?>