

<?php $__env->startSection('breadcrumb'); ?>
   <li class="breadcrumb-item">Dashboard</li>
   <li class="breadcrumb-item">Infaq Gedung</li>
   <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-md-12">
      <div class="card">
         <div class="card-body">
            <div class="card-title">Edit Pembayaran Infaq Gedung</div>
            
            <form method="post" action="<?php echo e(route('infaq.update', $edit->id)); ?>">
               <?php echo csrf_field(); ?>
               <?php echo method_field('put'); ?>
               
               <div class="form-group">
                  <label>NISN Siswa</label>
                  <input type="text" class="form-control" 
                         value="<?php echo e($edit->siswa->nisn); ?>" readonly>
               </div>
               
               <div class="form-group">
                  <label>Nama Siswa</label>
                  <input type="text" class="form-control" value="<?php echo e($edit->siswa->nama); ?>" readonly>
               </div>

               <div class="row">
                  <div class="col-md-6">
                     <div class="form-group">
                        <label>Paket Infaq</label>
                        <input type="text" class="form-control" 
                               value="<?php echo e($edit->infaqGedung->paket ?? '-'); ?>" readonly>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="form-group">
                        <label>Total Infaq Gedung</label>
                        <input type="text" class="form-control" 
                               value="Rp <?php echo e(number_format($edit->infaqGedung->nominal ?? 0, 0, ',', '.')); ?>" readonly>
                     </div>
                  </div>
               </div>

               <div class="form-group">
                  <label>Angsuran Ke</label>
                  <input type="number" class="form-control <?php $__errorArgs = ['angsuran_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                         name="angsuran_ke" value="<?php echo e(old('angsuran_ke', $edit->angsuran_ke)); ?>" required>
                  <span class="text-danger"><?php $__errorArgs = ['angsuran_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <div class="form-group">
                  <label>Jumlah Bayar</label>
                  <input type="number" class="form-control <?php $__errorArgs = ['jumlah_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                         name="jumlah_bayar" value="<?php echo e(old('jumlah_bayar', $edit->jumlah_bayar)); ?>" 
                         min="1" required>
                  <span class="text-danger"><?php $__errorArgs = ['jumlah_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <div class="form-group">
                  <label>Tanggal Bayar</label>
                  <input type="date" class="form-control <?php $__errorArgs = ['tgl_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                         name="tgl_bayar" value="<?php echo e(old('tgl_bayar', $edit->tgl_bayar->format('Y-m-d'))); ?>" required>
                  <span class="text-danger"><?php $__errorArgs = ['tgl_bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
               </div>

               <a href="<?php echo e(route('infaq.index')); ?>" class="btn btn-primary btn-rounded">
                  <i class="mdi mdi-chevron-left"></i> Kembali
               </a>
               <button type="submit" class="btn btn-success btn-rounded float-right">
                  <i class="mdi mdi-check"></i> Simpan Perubahan
               </button>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/infaq/edit.blade.php ENDPATH**/ ?>