

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Dashboard</li>
    <li class="breadcrumb-item">Kelas</li>
    <li class="breadcrumb-item active">Edit</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title"><?php echo e(__('Edit Kelas')); ?></div>
                    
                    <form method="post" action="<?php echo e(url('/dashboard/data-kelas', $edit->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        
                        <div class="form-group">
                            <label>Nama Kelas</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="nama_kelas" value="<?php echo e(old('nama_kelas', $edit->nama_kelas)); ?>">
                            <span class="text-danger"><?php $__errorArgs = ['nama_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                        </div>
                        
                        <div class="form-group">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" name="has_konsumsi" id="has_konsumsi" 
                                       value="1" <?php echo e($edit->has_konsumsi ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="has_konsumsi">Menyediakan Konsumsi</label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" name="has_fullday" id="has_fullday" 
                                       value="1" <?php echo e($edit->has_fullday ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="has_fullday">Program Fullday</label>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-success btn-rounded">
                            <i class="mdi mdi-check"></i> Simpan
                        </button>
                    </form>
                </div>
            </div>     
        </div>     
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('sweet'); ?>
function deleteData(id){
    Swal.fire({
        title: 'PERINGATAN!',
        text: "Yakin ingin menghapus data kelas?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yakin',
        cancelButtonText: 'Batal',
    }).then((result) => {
        if (result.value) {
            $('#delete'+id).submit();
        }
    });
}
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\project-pembayaran-spp\spp-tk\resources\views/dashboard/data-kelas/edit.blade.php ENDPATH**/ ?>